#version 150

// OG Prison "classic" lightmap: Beta 1.7.3 lighting on a 1.21.6-1.21.8 client.
//
// Beta 1.7.3 had no lightmap texture and no coloured light (both came in Beta
// 1.8). Every vertex was shaded by ONE grey value:
//     level      = max(blockLight, skyLight - skylightSubtracted)
//     brightness = (1 - f) / (3f + 1) * 0.95 + 0.05        with f = 1 - level / 15
// where skylightSubtracted ran from 0 (day) to 11 (night). No torch flicker,
// no warm torch tint, no blue nights, no brightness slider.
//
// The client still hands us the modern uniforms, so night vision, the
// darkness effect and the End's bright lightmap keep working exactly as in
// vanilla. Only the colour/brightness curve is Beta's.
//
// Pack overlay og_light_f63_64: this file is only served to pack formats
// 63-64 (1.21.6-1.21.8), the versions whose lightmap.fsh uses this uniform
// block. Newer clients get vanilla lighting until a port is checked.

layout(std140) uniform LightmapInfo {
    float AmbientLightFactor;
    float SkyFactor;          // ~ sun * 0.95 + 0.05 (1.0 during lightning)
    float BlockFactor;        // torch flicker, unused here (Beta had none)
    int UseBrightLightmap;
    float NightVisionFactor;
    float DarknessScale;
    float DarkenWorldFactor;
    float BrightnessFactor;   // the Brightness slider, unused (Beta had none)
    vec3 SkyLightColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

// Beta's lightBrightnessTable, level in 0..15
float beta_brightness(float level) {
    float f = 1.0 - level / 15.0;
    return (1.0 - f) / (f * 3.0 + 1.0) * 0.95 + 0.05;
}

void main() {
    float blockLevel = floor(texCoord.x * 16.0);
    float skyLevel = floor(texCoord.y * 16.0);

    // modern SkyFactor -> Beta's skylightSubtracted (0 by day, 11 at night)
    float sun = clamp((lightmapInfo.SkyFactor - 0.05) / 0.95, 0.0, 1.0);   // 0.2 (night) .. 1.0 (day)
    float night = clamp(1.0 - (sun - 0.2) / 0.8, 0.0, 1.0);
    float subtracted = floor(night * 11.0 + 0.5);

    float level = max(blockLevel, skyLevel - subtracted);
    float brightness = beta_brightness(clamp(level, 0.0, 15.0));
    vec3 color = vec3(brightness);

    if (lightmapInfo.UseBrightLightmap != 0) {
        // the End: keep vanilla's flat bright lightmap
        color = mix(color, vec3(0.99, 1.12, 1.0), 0.25);
        color = clamp(color, 0.0, 1.0);
    } else {
        vec3 darkened_color = color * vec3(0.7, 0.6, 0.6);
        color = mix(color, darkened_color, lightmapInfo.DarkenWorldFactor);
    }

    if (lightmapInfo.NightVisionFactor > 0.0) {
        // vanilla rule: scale up until one channel hits 1.0 - with a grey
        // lightmap that is full brightness everywhere, as night vision should be
        float max_component = max(color.r, max(color.g, color.b));
        if (max_component < 1.0) {
            vec3 bright_color = color / max_component;
            color = mix(color, bright_color, lightmapInfo.NightVisionFactor);
        }
    }

    if (lightmapInfo.UseBrightLightmap == 0) {
        color = clamp(color - vec3(lightmapInfo.DarknessScale), 0.0, 1.0);
    }

    // Beta had no brightness slider. To honour the player's slider anyway,
    // change 0.0 below to lightmapInfo.BrightnessFactor.
    const float OG_GAMMA = 0.0;
    vec3 nx = 1.0 - color;
    vec3 notGamma = 1.0 - nx * nx * nx * nx;
    color = mix(color, notGamma, OG_GAMMA);
    color = clamp(color, 0.0, 1.0);

    fragColor = vec4(color, 1.0);
}
