#version 330

// SummitMC (design/77): vanilla 26.1 rendertype_text_intensity.fsh + animated paints.
// Palettes mirror NamePaint.java / ChatTone.java. Same math as the 1.21.8
// port. Intensity twin differs only in the .rrrr swizzle.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
flat in int paintId;
in float paintMul;
in float paintPos;

out vec4 fragColor;

const float PAINT_SPEED = 600.0; // gradient cycles per 20-min day (0.5/sec)
const float PAINT_WIDTH = 160.0; // gui px per full gradient loop

vec3 hsv2rgb(vec3 c) {
    vec3 p = abs(fract(c.xxx + vec3(0.0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0);
    return c.z * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), c.y);
}

vec3 seg(vec3 a, vec3 b, float f) {
    return mix(a, b, smoothstep(0.0, 1.0, f));
}

vec3 cyc3(vec3 a, vec3 b, vec3 c, float t) {
    float f = fract(t) * 3.0;
    if (f < 1.0) return seg(a, b, f);
    if (f < 2.0) return seg(b, c, f - 1.0);
    return seg(c, a, f - 2.0);
}

vec3 cyc5(vec3 a, vec3 b, vec3 c, vec3 d, vec3 e, float t) {
    float f = fract(t) * 5.0;
    if (f < 1.0) return seg(a, b, f);
    if (f < 2.0) return seg(b, c, f - 1.0);
    if (f < 3.0) return seg(c, d, f - 2.0);
    if (f < 4.0) return seg(d, e, f - 3.0);
    return seg(e, a, f - 4.0);
}

vec3 paint_color(int id, float t) {
    if (id == 1) return hsv2rgb(vec3(fract(t), 0.85, 1.0));                 // rainbow
    if (id == 2) return cyc3(vec3(0.498, 0.0, 1.0),                        // galaxy
                             vec3(0.882, 0.0, 1.0),
                             vec3(0.0, 0.765, 1.0), t);
    if (id == 3) return cyc3(vec3(0.0, 1.0, 0.639),                        // aurora
                             vec3(0.012, 0.882, 1.0),
                             vec3(0.863, 0.122, 1.0), t);
    if (id == 4) return cyc3(vec3(1.0, 0.843, 0.0),                        // gold rush
                             vec3(1.0, 0.953, 0.690),
                             vec3(0.722, 0.525, 0.043), t);
    if (id == 5) return cyc3(vec3(0.169, 0.839, 0.482),                    // emerald wave
                             vec3(0.722, 1.0, 0.851),
                             vec3(0.090, 0.620, 0.333), t);
    if (id == 7) return cyc3(vec3(0.749, 0.937, 1.0),                      // frostbite
                             vec3(1.0, 1.0, 1.0),
                             vec3(0.302, 0.651, 0.839), t);
    if (id == 8) return cyc3(vec3(1.0, 0.271, 0.0),                        // molten
                             vec3(1.0, 0.647, 0.0),
                             vec3(0.545, 0.0, 0.0), t);
    if (id == 9) return cyc3(vec3(0.294, 0.0, 0.510),                      // midnight
                             vec3(0.576, 0.439, 0.859),
                             vec3(0.051, 0.051, 0.169), t);
    if (id == 10) return cyc3(vec3(0.0, 0.467, 0.745),                     // riptide
                              vec3(0.0, 0.788, 0.910),
                              vec3(0.910, 0.992, 1.0), t);
    if (id == 11) return cyc3(vec3(1.0, 0.718, 0.773),                     // sakura
                              vec3(1.0, 1.0, 1.0),
                              vec3(0.910, 0.302, 0.435), t);
    if (id == 12) return cyc3(vec3(1.0, 1.0, 0.2),                         // voltage
                              vec3(1.0, 1.0, 1.0),
                              vec3(0.2, 0.8, 1.0), t);
    if (id == 13) return cyc3(vec3(0.224, 1.0, 0.078),                     // venom
                              vec3(0.059, 0.628, 0.353),
                              vec3(0.043, 0.180, 0.075), t);
    if (id == 14) return cyc3(vec3(0.608, 0.365, 0.898),                   // dawn
                              vec3(1.0, 0.420, 0.612),
                              vec3(1.0, 0.757, 0.271), t);
    if (id == 15) return cyc3(vec3(1.0, 0.443, 0.808),                     // vaporwave
                              vec3(0.725, 0.404, 1.0),
                              vec3(0.004, 0.804, 0.996), t);
    if (id == 16) return cyc3(vec3(0.910, 0.973, 1.0),                     // comet
                              vec3(0.302, 0.624, 1.0),
                              vec3(0.039, 0.122, 0.267), t);
    return cyc5(vec3(1.0, 0.702, 0.729),                                   // prism
                vec3(1.0, 0.875, 0.729),
                vec3(1.0, 1.0, 0.729),
                vec3(0.729, 1.0, 0.788),
                vec3(0.729, 0.882, 1.0), t);
}

void main() {
    vec4 color = texture(Sampler0, texCoord0).rrrr * vertexColor * ColorModulator;
    if (paintId != 0) {
        float t = paintPos / PAINT_WIDTH - GameTime * PAINT_SPEED;
        color.rgb *= paint_color(paintId, t) * paintMul;
    }
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
