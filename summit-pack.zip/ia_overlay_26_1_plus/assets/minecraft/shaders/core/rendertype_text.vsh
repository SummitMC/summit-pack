#version 330

// SummitMC (design/77): vanilla 26.1 rendertype_text.vsh + animated-paint key
// detection. For clients on pack formats 84-87 (injected by patch-pack.ps1
// into ia_overlay_26_1_plus). Key table MUST match NamePaint/ChatTone.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
flat out int paintId;
out float paintMul;
out float paintPos;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;

    ivec3 c = ivec3(round(Color.rgb * 255.0));
    paintId = 0;
    paintMul = 1.0;
    paintPos = 0.0;
    if      (c == ivec3(251,  85,  84)) paintId = 1;                        // rainbow FB5554
    else if (c == ivec3( 62,  21,  21)) { paintId = 1; paintMul = 0.25; }
    else if (c == ivec3(225,   0, 254)) paintId = 2;                        // galaxy E100FE
    else if (c == ivec3( 56,   0,  63)) { paintId = 2; paintMul = 0.25; }
    else if (c == ivec3(  3, 225, 254)) paintId = 3;                        // aurora 03E1FE
    else if (c == ivec3(  0,  56,  63)) { paintId = 3; paintMul = 0.25; }
    else if (c == ivec3(255, 215,   5)) paintId = 4;                        // gold rush FFD705
    else if (c == ivec3( 63,  53,   1)) { paintId = 4; paintMul = 0.25; }
    else if (c == ivec3( 43, 214, 124)) paintId = 5;                        // emerald wave 2BD67C
    else if (c == ivec3( 10,  53,  31)) { paintId = 5; paintMul = 0.25; }
    else if (c == ivec3(255, 179, 189)) paintId = 6;                        // prism FFB3BD
    else if (c == ivec3( 63,  44,  47)) { paintId = 6; paintMul = 0.25; }
    else if (c == ivec3(191, 239, 251)) paintId = 7;                        // frostbite BFEFFB
    else if (c == ivec3( 47,  59,  62)) { paintId = 7; paintMul = 0.25; }
    else if (c == ivec3(255,  69,   1)) paintId = 8;                        // molten FF4501
    else if (c == ivec3( 63,  17,   0)) { paintId = 8; paintMul = 0.25; }
    else if (c == ivec3( 75,   0, 134)) paintId = 9;                        // midnight 4B0086
    else if (c == ivec3( 18,   0,  33)) { paintId = 9; paintMul = 0.25; }
    else if (c == ivec3(  0, 119, 186)) paintId = 10;                       // riptide 0077BA
    else if (c == ivec3(  0,  29,  46)) { paintId = 10; paintMul = 0.25; }
    else if (c == ivec3(255, 183, 193)) paintId = 11;                       // sakura FFB7C1
    else if (c == ivec3( 63,  45,  48)) { paintId = 11; paintMul = 0.25; }
    else if (c == ivec3(255, 255,  55)) paintId = 12;                       // voltage FFFF37
    else if (c == ivec3( 63,  63,  13)) { paintId = 12; paintMul = 0.25; }
    else if (c == ivec3( 57, 255,  16)) paintId = 13;                       // venom 39FF10
    else if (c == ivec3( 14,  63,   4)) { paintId = 13; paintMul = 0.25; }
    else if (c == ivec3(155,  93, 225)) paintId = 14;                       // dawn 9B5DE1
    else if (c == ivec3( 38,  23,  56)) { paintId = 14; paintMul = 0.25; }
    else if (c == ivec3(255, 113, 202)) paintId = 15;                       // vaporwave FF71CA
    else if (c == ivec3( 63,  28,  50)) { paintId = 15; paintMul = 0.25; }
    else if (c == ivec3(232, 248, 251)) paintId = 16;                       // comet E8F8FB
    else if (c == ivec3( 58,  62,  62)) { paintId = 16; paintMul = 0.25; }

    if (paintId != 0) {
        vertexColor = sample_lightmap(Sampler2, UV2) * vec4(1.0, 1.0, 1.0, Color.a);
        if (ProjMat[3][3] < 0.5) {
            // World text (nametags): VIEW-space X spans the billboarded name
            // at every camera angle — per-pixel smooth, batch-independent.
            vec4 vp = ModelViewMat * vec4(Position, 1.0);
            paintPos = (vp.x + vp.y * 0.25) * 130.0;
        } else {
            paintPos = Position.x + Position.y * 0.25;
        }
    }
}
